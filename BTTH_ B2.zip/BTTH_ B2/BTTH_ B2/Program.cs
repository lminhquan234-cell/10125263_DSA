﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BTTH__B2
{
    struct NhanVien
    {
        public string MaNV;
        public string Hoten;
        public int Namsinh;
        public string Phongban;
        public int LuongCB;
        public int Thuong;
        public int ThucLinh => LuongCB + Thuong;
    }

    class Node
    {
        public int Info;
        public Node Link;

        public Node(int info)
        {
            Info = info;
            Link = null;
        }
    }

    class DNode
    {
        public string Data;
        public DNode Prev;
        public DNode Next;

        public DNode(string data)
        {
            Data = data;
            Prev = null;
            Next = null;
        }
    }

    class Bai1
    {
        static int[] a = { 10, 20, 30, 40, 50 };

        static void Nhap()
        {
            Console.Write("Nhap so phan tu n: ");
            int n = int.Parse(Console.ReadLine());

            if (n < 0)
            {
                Console.WriteLine("n khong hop le!");
                return;
            }

            a = new int[n];

            for (int i = 0; i < n; i++)
            {
                Console.Write("a[" + i + "] = ");
                a[i] = int.Parse(Console.ReadLine());
            }
        }

        static void HienThi()
        {
            Console.Write("Danh sach: ");
            for (int i = 0; i < a.Length; i++)
                Console.Write(a[i] + " ");

            Console.WriteLine();
        }

        static void Chen()
        {
            Console.Write("Nhap x: ");
            int x = int.Parse(Console.ReadLine());

            Console.Write("Nhap vi tri k: ");
            int k = int.Parse(Console.ReadLine());

            if (k < 0 || k > a.Length)
            {
                Console.WriteLine("Vi tri khong hop le!");
                return;
            }

            int[] b = new int[a.Length + 1];

            for (int i = 0; i < k; i++)
                b[i] = a[i];

            b[k] = x;

            for (int i = k; i < a.Length; i++)
                b[i + 1] = a[i];

            a = b;
            HienThi();
        }

        public static void Run()
        {
            while (true)
            {
                Console.WriteLine("\n--- BAI 1 ---");
                Console.WriteLine("a. Nhap mang");
                Console.WriteLine("b. Hien thi");
                Console.WriteLine("c. Chen phan tu");
                Console.WriteLine("0. Quay lai");
                Console.Write("Chon: ");

                string chon = Console.ReadLine();

                switch (chon)
                {
                    case "a": Nhap(); break;
                    case "b": HienThi(); break;
                    case "c": Chen(); break;
                    case "0": return;
                }
            }
        }
    }

    class Bai2
    {
        static NhanVien[] DS =
        {
            new NhanVien {
                MaNV = "NV01",
                Hoten = "Nguyễn Văn An",
                Namsinh = 1995,
                Phongban = "IT",
                LuongCB = 12000000,
                Thuong = 1500000
            },
            new NhanVien {
                MaNV = "NV03",
                Hoten = "Trần Thị Bình",
                Namsinh = 1998,
                Phongban = "Kế toán",
                LuongCB = 8000000,
                Thuong = 1000000
            },
            new NhanVien {
                MaNV = "NV02",
                Hoten = "Lê Hoàng Cường",
                Namsinh = 1996,
                Phongban = "IT",
                LuongCB = 8000000,
                Thuong = 2000000
            },
            new NhanVien {
                MaNV = "NV04",
                Hoten = "Phạm Minh Dung",
                Namsinh = 1999,
                Phongban = "Nhân sự",
                LuongCB = 10000000,
                Thuong = 1200000
            }
        };

        public static void Run()
        {
            while (true)
            {
                Console.WriteLine("\n--- BAI 2: NHAN VIEN ---");
                Console.WriteLine("a. Tong thuc linh");
                Console.WriteLine("b. Luong co ban thap nhat");
                Console.WriteLine("c. Dem nhan vien thuong >= 1200000");
                Console.WriteLine("d. Sap xep nhan vien");
                Console.WriteLine("e. Tang luong 5%");
                Console.WriteLine("0. Quay lai");
                Console.Write("Chon: ");

                string chon = Console.ReadLine();

                switch (chon)
                {
                    case "a":
                        long tong = 0;

                        for (int i = 0; i < DS.Length; i++)
                            tong += DS[i].ThucLinh;

                        Console.WriteLine("Tong: " + tong);
                        break;

                    case "b":
                        int min = DS[0].LuongCB;

                        for (int i = 1; i < DS.Length; i++)
                            if (DS[i].LuongCB < min)
                                min = DS[i].LuongCB;

                        for (int i = 0; i < DS.Length; i++)
                            if (DS[i].LuongCB == min)
                                Console.WriteLine(
                                    DS[i].MaNV + " - " +
                                    DS[i].Hoten + " - " + min);
                        break;

                    case "c":
                        int dem = 0;

                        for (int i = 0; i < DS.Length; i++)
                            if (DS[i].Thuong >= 1200000)
                                dem++;

                        Console.WriteLine("So nhan vien: " + dem);
                        break;

                    case "d":
                        NhanVien[] sx = (NhanVien[])DS.Clone();

                        for (int i = 0; i < sx.Length - 1; i++)
                        {
                            for (int j = i + 1; j < sx.Length; j++)
                            {
                                int cmp = string.Compare(
                                    sx[i].Phongban,
                                    sx[j].Phongban,
                                    StringComparison.Ordinal);

                                if (cmp > 0 ||
                                    (cmp == 0 &&
                                    string.Compare(
                                        sx[i].MaNV,
                                        sx[j].MaNV,
                                        StringComparison.Ordinal) < 0))
                                {
                                    NhanVien t = sx[i];
                                    sx[i] = sx[j];
                                    sx[j] = t;
                                }
                            }
                        }

                        foreach (NhanVien nv in sx)
                            Console.WriteLine(
                                nv.Phongban + " - " +
                                nv.MaNV + " - " + nv.Hoten);
                        break;

                    case "e":
                        for (int i = 0; i < DS.Length; i++)
                        {
                            DS[i].LuongCB =
                                (int)(DS[i].LuongCB * 1.05);

                            Console.WriteLine(
                                DS[i].Hoten + ": " +
                                DS[i].LuongCB);
                        }
                        break;

                    case "0": return;
                }
            }
        }
    }

    class Bai3
    {
        static int[,] a =
        {
            { 2, -4, 7 },
            { 5, 6, 1 },
            { 9, 3, 8 }
        };

        public static void Run()
        {
            int n = a.GetLength(0);

            while (true)
            {
                Console.WriteLine("\n--- BAI 3 ---");
                Console.WriteLine("a. Tong phan tu");
                Console.WriteLine("b. So duong nho nhat");
                Console.WriteLine("c. Tong duong cheo phu");
                Console.WriteLine("d. Kiem tra cheo chinh tang dan");
                Console.WriteLine("0. Quay lai");
                Console.Write("Chon: ");

                string chon = Console.ReadLine();

                switch (chon)
                {
                    case "a":
                        int tong = 0;

                        foreach (int x in a)
                            tong += x;

                        Console.WriteLine("Tong = " + tong);
                        break;

                    case "b":
                        int min = int.MaxValue;

                        foreach (int x in a)
                            if (x > 0 && x < min)
                                min = x;

                        if (min == int.MaxValue)
                            Console.WriteLine("Khong co so duong");
                        else
                            Console.WriteLine("Min = " + min);
                        break;

                    case "c":
                        int s = 0;

                        for (int i = 0; i < n; i++)
                            s += a[i, n - 1 - i];

                        Console.WriteLine("Tong cheo phu = " + s);
                        break;

                    case "d":
                        bool tang = true;

                        for (int i = 0; i < n - 1; i++)
                            if (a[i, i] >= a[i + 1, i + 1])
                                tang = false;

                        Console.WriteLine("Tang dan: " + tang);
                        break;

                    case "0": return;
                }
            }
        }
    }

    class Bai4
    {
        public static void ThemCuoi(ref Node head, int x)
        {
            Node node = new Node(x);

            if (head == null)
            {
                head = node;
                return;
            }

            Node p = head;

            while (p.Link != null)
                p = p.Link;

            p.Link = node;
        }

        public static void InDSLK(Node head)
        {
            Node p = head;

            while (p != null)
            {
                Console.Write(p.Info + " -> ");
                p = p.Link;
            }

            Console.WriteLine("null");
        }

        public static void Run()
        {
            Node head = null;

            int[] a = { 5, 12, 3, 12, 8, 20 };

            foreach (int x in a)
                ThemCuoi(ref head, x);

            while (true)
            {
                Console.WriteLine("\n--- BAI 4 ---");
                InDSLK(head);
                Console.WriteLine("a. Dem x");
                Console.WriteLine("b. So duong nho nhat");
                Console.WriteLine("c. Xoa x dau tien");
                Console.WriteLine("0. Quay lai");
                Console.Write("Chon: ");

                string chon = Console.ReadLine();

                switch (chon)
                {
                    case "a":
                        Console.Write("Nhap x: ");
                        int x = int.Parse(Console.ReadLine());
                        int dem = 0;

                        for (Node p = head; p != null; p = p.Link)
                            if (p.Info == x)
                                dem++;

                        Console.WriteLine("So luong = " + dem);
                        break;

                    case "b":
                        int min = int.MaxValue;

                        for (Node p = head; p != null; p = p.Link)
                            if (p.Info > 0 && p.Info < min)
                                min = p.Info;

                        if (min == int.MaxValue)
                            Console.WriteLine("Khong co so duong");
                        else
                            Console.WriteLine("Min = " + min);
                        break;

                    case "c":
                        Console.Write("Nhap x can xoa: ");
                        int k = int.Parse(Console.ReadLine());

                        Node curr = head;
                        Node prev = null;

                        while (curr != null && curr.Info != k)
                        {
                            prev = curr;
                            curr = curr.Link;
                        }

                        if (curr == null)
                            Console.WriteLine("Khong tim thay");
                        else if (prev == null)
                            head = curr.Link;
                        else
                            prev.Link = curr.Link;

                        InDSLK(head);
                        break;

                    case "0": return;
                }
            }
        }
    }

    class Bai5
    {
        static bool KTNT(int n)
        {
            if (n < 2) return false;

            for (int i = 2; i <= Math.Sqrt(n); i++)
                if (n % i == 0)
                    return false;

            return true;
        }

        public static void Run()
        {
            Node head = null;
            int[] a = { -5, 7, 0, 12, -3, 7, 2, 15 };

            foreach (int x in a)
                Bai4.ThemCuoi(ref head, x);

            while (true)
            {
                Console.WriteLine("\n--- BAI 5 ---");
                Bai4.InDSLK(head);
                Console.WriteLine("a. Max");
                Console.WriteLine("b. Tong");
                Console.WriteLine("c. Dem so nguyen to");
                Console.WriteLine("d. Dem am, duong, 0");
                Console.WriteLine("e. Dem x");
                Console.WriteLine("f. So duong nho nhat");
                Console.WriteLine("0. Quay lai");
                Console.Write("Chon: ");

                string chon = Console.ReadLine();

                switch (chon)
                {
                    case "a":
                        int max = int.MinValue;

                        for (Node p = head; p != null; p = p.Link)
                            if (p.Info > max)
                                max = p.Info;

                        Console.WriteLine("Max = " + max);
                        break;

                    case "b":
                        int tong = 0;

                        for (Node p = head; p != null; p = p.Link)
                            tong += p.Info;

                        Console.WriteLine("Tong = " + tong);
                        break;

                    case "c":
                        int dem = 0;

                        for (Node p = head; p != null; p = p.Link)
                            if (KTNT(p.Info))
                                dem++;

                        Console.WriteLine("So nguyen to = " + dem);
                        break;

                    case "d":
                        int am = 0, duong = 0, khong = 0;

                        for (Node p = head; p != null; p = p.Link)
                        {
                            if (p.Info < 0) am++;
                            else if (p.Info > 0) duong++;
                            else khong++;
                        }

                        Console.WriteLine(
                            "Am: " + am +
                            ", Duong: " + duong +
                            ", So 0: " + khong);
                        break;

                    case "e":
                        Console.Write("Nhap x: ");
                        int x = int.Parse(Console.ReadLine());
                        int d = 0;

                        for (Node p = head; p != null; p = p.Link)
                            if (p.Info == x)
                                d++;

                        Console.WriteLine("So luong = " + d);
                        break;

                    case "f":
                        int min = int.MaxValue;

                        for (Node p = head; p != null; p = p.Link)
                            if (p.Info > 0 && p.Info < min)
                                min = p.Info;

                        if (min == int.MaxValue)
                            Console.WriteLine("Khong co so duong");
                        else
                            Console.WriteLine("Min = " + min);
                        break;

                    case "0": return;
                }
            }
        }
    }

    class Bai7
    {
        public static void Run()
        {
            Console.WriteLine("\n--- BAI 7: NHIET DO ---");
            Console.Write("Nhap so ngay (Enter de dung mau): ");
            string s = Console.ReadLine();

            double[] a;

            if (string.IsNullOrWhiteSpace(s))
                a = new double[] { 28.5, 30, 32.2, 29.8, 27, 31.5, 33 };
            else
            {
                int n = int.Parse(s);

                if (n <= 0)
                {
                    Console.WriteLine("So ngay phai lon hon 0");
                    return;
                }

                a = new double[n];

                for (int i = 0; i < n; i++)
                {
                    Console.Write("Ngay " + (i + 1) + ": ");
                    a[i] = double.Parse(Console.ReadLine());
                }
            }

            double max = a[0], min = a[0], tong = 0;
            int ngayMax = 1, ngayMin = 1;

            for (int i = 0; i < a.Length; i++)
            {
                tong += a[i];

                if (a[i] > max)
                {
                    max = a[i];
                    ngayMax = i + 1;
                }

                if (a[i] < min)
                {
                    min = a[i];
                    ngayMin = i + 1;
                }
            }

            Console.WriteLine("Ngay cao nhat: " + ngayMax + " - " + max);
            Console.WriteLine("Ngay thap nhat: " + ngayMin + " - " + min);
            Console.WriteLine("Trung binh: " + (tong / a.Length));
        }
    }

    class Bai8
    {
        public static void Run()
        {
            Console.WriteLine("\n--- BAI 8: THONG KE TU ---");
            Console.Write("Nhap van ban: ");
            string s = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(s))
                s = "Học cấu trúc dữ liệu và giải thuật, học lập trình C# rất thú vị!";

            StringBuilder sb = new StringBuilder();

            foreach (char c in s.ToLower())
            {
                if (char.IsLetterOrDigit(c))
                    sb.Append(c);
                else
                    sb.Append(' ');
            }

            string[] words = sb.ToString().Split(
                new char[] { ' ', '\t', '\n' },
                StringSplitOptions.RemoveEmptyEntries);

            Dictionary<string, int> dem = new Dictionary<string, int>();

            foreach (string w in words)
            {
                if (dem.ContainsKey(w))
                    dem[w]++;
                else
                    dem[w] = 1;
            }

            foreach (var item in dem.OrderByDescending(x => x.Value)
                                    .ThenBy(x => x.Key))
                Console.WriteLine(item.Key + ": " + item.Value);
        }
    }

    class Bai9
    {
        static bool NguyenTo(int n)
        {
            if (n < 2) return false;

            for (int i = 2; i <= Math.Sqrt(n); i++)
                if (n % i == 0) return false;

            return true;
        }

        static bool HoanHao(int n)
        {
            if (n <= 1) return false;

            int tong = 1;

            for (int i = 2; i <= n / 2; i++)
                if (n % i == 0)
                    tong += i;

            return tong == n;
        }

        public static void Run()
        {
            int[] a = { 2, 6, 7, 10, 13, 28, 15, 4, 29 };

            Console.WriteLine("\n--- BAI 9 ---");

            Console.Write("So nguyen to: ");
            foreach (int x in a)
                if (NguyenTo(x))
                    Console.Write(x + " ");

            Console.Write("\nSo chan: ");
            foreach (int x in a)
                if (x % 2 == 0)
                    Console.Write(x + " ");

            Console.Write("\nSo hoan hao: ");
            foreach (int x in a)
                if (HoanHao(x))
                    Console.Write(x + " ");

            Console.WriteLine();
        }
    }

    class Bai10
    {
        public static void Run()
        {
            int[,] a =
            {
                { 1, 2, 3, 4 },
                { 5, 6, 7, 8 },
                { 9, 10, 11, 12 },
                { 13, 14, 15, 16 }
            };

            int top = 0, bottom = 3;
            int left = 0, right = 3;

            Console.WriteLine("\n--- BAI 10: XOAN OC ---");

            while (top <= bottom && left <= right)
            {
                for (int i = left; i <= right; i++)
                    Console.Write(a[top, i] + " ");
                top++;

                for (int i = top; i <= bottom; i++)
                    Console.Write(a[i, right] + " ");
                right--;

                if (top <= bottom)
                {
                    for (int i = right; i >= left; i--)
                        Console.Write(a[bottom, i] + " ");
                    bottom--;
                }

                if (left <= right)
                {
                    for (int i = bottom; i >= top; i--)
                        Console.Write(a[i, left] + " ");
                    left++;
                }
            }

            Console.WriteLine();
        }
    }

    class Bai11
    {
        static bool DonVi(int[,] a)
        {
            int n = a.GetLength(0);

            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                {
                    if (i == j && a[i, j] != 1)
                        return false;

                    if (i != j && a[i, j] != 0)
                        return false;
                }

            return true;
        }

        static bool DoiXung(int[,] a)
        {
            int n = a.GetLength(0);

            for (int i = 0; i < n; i++)
                for (int j = i + 1; j < n; j++)
                    if (a[i, j] != a[j, i])
                        return false;

            return true;
        }

        public static void Run()
        {
            int[,] a =
            {
                { 1, 0, 0 },
                { 0, 1, 0 },
                { 0, 0, 1 }
            };

            int[,] b =
            {
                { 1, 2, 3 },
                { 2, 4, 5 },
                { 3, 5, 6 }
            };

            Console.WriteLine("\n--- BAI 11 ---");
            Console.WriteLine("Ma tran 1 don vi: " + DonVi(a));
            Console.WriteLine("Ma tran 1 doi xung: " + DoiXung(a));
            Console.WriteLine("Ma tran 2 don vi: " + DonVi(b));
            Console.WriteLine("Ma tran 2 doi xung: " + DoiXung(b));
        }
    }

    class Bai12
    {
        public static void Run()
        {
            Console.WriteLine("\n--- BAI 12: MINESWEEPER ---");

            Console.Write("Nhap so dong (Enter = 5): ");
            string sm = Console.ReadLine();
            int m = string.IsNullOrWhiteSpace(sm) ? 5 : int.Parse(sm);

            Console.Write("Nhap so cot (Enter = 5): ");
            string sn = Console.ReadLine();
            int n = string.IsNullOrWhiteSpace(sn) ? 5 : int.Parse(sn);

            if (m <= 0 || n <= 0)
            {
                Console.WriteLine("Kich thuoc khong hop le");
                return;
            }

            char[,] a = new char[m, n];

            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                    a[i, j] = '.';

            Random rd = new Random();
            int soMin = m * n / 5;
            int dem = 0;

            while (dem < soMin)
            {
                int x = rd.Next(m);
                int y = rd.Next(n);

                if (a[x, y] != '*')
                {
                    a[x, y] = '*';
                    dem++;
                }
            }

            int[] dx = { -1, -1, -1, 0, 0, 1, 1, 1 };
            int[] dy = { -1, 0, 1, -1, 1, -1, 0, 1 };

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (a[i, j] == '*')
                    {
                        Console.Write(" * ");
                    }
                    else
                    {
                        int count = 0;

                        for (int k = 0; k < 8; k++)
                        {
                            int x = i + dx[k];
                            int y = j + dy[k];

                            if (x >= 0 && x < m &&
                                y >= 0 && y < n &&
                                a[x, y] == '*')
                                count++;
                        }

                        Console.Write(" " + count + " ");
                    }
                }

                Console.WriteLine();
            }
        }
    }

    class Bai13
    {
        public static void Run()
        {
            Node head = null;

            foreach (int x in new int[] { 10, 20, 30, 40, 50 })
                Bai4.ThemCuoi(ref head, x);

            Console.WriteLine("\n--- BAI 13 ---");
            Bai4.InDSLK(head);

            Node prev = null;
            Node curr = head;

            while (curr != null)
            {
                Node next = curr.Link;
                curr.Link = prev;
                prev = curr;
                curr = next;
            }

            head = prev;

            Console.WriteLine("Sau khi dao nguoc:");
            Bai4.InDSLK(head);
        }
    }

    class Bai14
    {
        public static void Run()
        {
            Node a = null;
            Node b = null;

            foreach (int x in new int[] { 1, 4, 7, 10 })
                Bai4.ThemCuoi(ref a, x);

            foreach (int x in new int[] { 2, 3, 6, 8, 12 })
                Bai4.ThemCuoi(ref b, x);

            Node dummy = new Node(0);
            Node tail = dummy;

            while (a != null && b != null)
            {
                if (a.Info <= b.Info)
                {
                    tail.Link = a;
                    a = a.Link;
                }
                else
                {
                    tail.Link = b;
                    b = b.Link;
                }

                tail = tail.Link;
            }

            if (a != null)
                tail.Link = a;
            else
                tail.Link = b;

            Console.WriteLine("\n--- BAI 14 ---");
            Bai4.InDSLK(dummy.Link);
        }
    }

    class Bai15
    {
        static bool CoChuTrinh(Node head)
        {
            Node slow = head;
            Node fast = head;

            while (fast != null && fast.Link != null)
            {
                slow = slow.Link;
                fast = fast.Link.Link;

                if (slow == fast)
                    return true;
            }

            return false;
        }

        public static void Run()
        {
            Node a = new Node(2);
            Node b = new Node(3);
            Node c = new Node(4);
            Node d = new Node(5);
            Node e = new Node(6);

            a.Link = b;
            b.Link = c;
            c.Link = d;
            d.Link = e;
            e.Link = a;

            Node thuong = null;

            foreach (int x in new int[] { 1, 2, 3, 4 })
                Bai4.ThemCuoi(ref thuong, x);

            Console.WriteLine("\n--- BAI 15 ---");
            Console.WriteLine("DSLK 1 co chu trinh: " + CoChuTrinh(a));
            Console.WriteLine("DSLK 2 co chu trinh: " + CoChuTrinh(thuong));
        }
    }

    class Bai16
    {
        public static void Run()
        {
            DNode current = new DNode("google.com");

            DNode github = new DNode("github.com");
            current.Next = github;
            github.Prev = current;
            current = github;

            DNode utehy = new DNode("utehy.edu.vn");
            current.Next = utehy;
            utehy.Prev = current;
            current = utehy;

            while (true)
            {
                Console.WriteLine("\n--- BAI 16 ---");
                Console.WriteLine("Trang: " + current.Data);
                Console.WriteLine("1. Truy cap trang moi");
                Console.WriteLine("2. Back");
                Console.WriteLine("3. Forward");
                Console.WriteLine("0. Quay lai");
                Console.Write("Chon: ");

                string chon = Console.ReadLine();

                if (chon == "1")
                {
                    Console.Write("Nhap URL: ");
                    string url = Console.ReadLine();

                    DNode node = new DNode(url);
                    current.Next = node;
                    node.Prev = current;
                    current = node;
                }
                else if (chon == "2")
                {
                    if (current.Prev != null)
                        current = current.Prev;
                    else
                        Console.WriteLine("Khong the Back");
                }
                else if (chon == "3")
                {
                    if (current.Next != null)
                        current = current.Next;
                    else
                        Console.WriteLine("Khong the Forward");
                }
                else if (chon == "0")
                    return;
            }
        }
    }

    class Bai17
    {
        public static void Run()
        {
            DNode head = new DNode("Lạc Trôi - Sơn Tùng M-TP");
            DNode b = new DNode("Nàng Thơ - Hoàng Dũng");
            DNode c = new DNode("Cắt Đôi Nỗi Sầu - Tăng Duy Tân");

            head.Next = b;
            b.Prev = head;
            b.Next = c;
            c.Prev = b;

            DNode tail = c;
            DNode current = head;

            while (true)
            {
                Console.WriteLine("\n--- BAI 17: PLAYLIST ---");
                Console.WriteLine("Dang phat: " +
                    (current == null ? "Trong" : current.Data));
                Console.WriteLine("1. Next");
                Console.WriteLine("2. Previous");
                Console.WriteLine("3. Them bai");
                Console.WriteLine("4. Xoa bai dang phat");
                Console.WriteLine("0. Quay lai");
                Console.Write("Chon: ");

                string chon = Console.ReadLine();

                if (chon == "1")
                {
                    if (current != null && current.Next != null)
                        current = current.Next;
                    else
                        Console.WriteLine("Da o cuoi danh sach");
                }
                else if (chon == "2")
                {
                    if (current != null && current.Prev != null)
                        current = current.Prev;
                    else
                        Console.WriteLine("Da o dau danh sach");
                }
                else if (chon == "3")
                {
                    Console.Write("Ten bai hat: ");
                    string ten = Console.ReadLine();
                    DNode node = new DNode(ten);

                    if (head == null)
                    {
                        head = node;
                        tail = node;
                        current = node;
                    }
                    else
                    {
                        tail.Next = node;
                        node.Prev = tail;
                        tail = node;
                    }
                }
                else if (chon == "4")
                {
                    if (current == null)
                    {
                        Console.WriteLine("Danh sach rong");
                    }
                    else
                    {
                        DNode next = current.Next;
                        DNode prev = current.Prev;

                        if (prev != null)
                            prev.Next = next;
                        else
                            head = next;

                        if (next != null)
                            next.Prev = prev;
                        else
                            tail = prev;

                        current = next != null ? next : prev;
                    }
                }
                else if (chon == "0")
                    return;
            }
        }
    }

    class Bai18
    {
        public static void Run()
        {
            DNode s1 = new DNode("Chờ xử lý");
            DNode s2 = new DNode("Đang giao");
            DNode s3 = new DNode("Hoàn thành");

            s1.Next = s2;
            s2.Prev = s1;
            s2.Next = s3;
            s3.Prev = s2;

            DNode current = s1;
            string maDon = "DH_12425044";

            while (true)
            {
                Console.WriteLine("\n--- BAI 18 ---");
                Console.WriteLine("Ma don: " + maDon);
                Console.WriteLine("Trang thai: " + current.Data);
                Console.WriteLine("1. Trang thai tiep");
                Console.WriteLine("2. Trang thai truoc");
                Console.WriteLine("0. Quay lai");
                Console.Write("Chon: ");

                string chon = Console.ReadLine();

                if (chon == "1")
                {
                    if (current.Next != null)
                        current = current.Next;
                    else
                        Console.WriteLine("Da hoan thanh");
                }
                else if (chon == "2")
                {
                    if (current.Prev != null)
                        current = current.Prev;
                    else
                        Console.WriteLine("Dang o trang thai dau");
                }
                else if (chon == "0")
                    return;
            }
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("========== BTTH BUOI 2 ==========");
                Console.WriteLine("1. Mang mot chieu");
                Console.WriteLine("2. Quan ly nhan vien");
                Console.WriteLine("3. Ma tran vuong");
                Console.WriteLine("4. DSLK don so nguyen duong");
                Console.WriteLine("5. DSLK don so nguyen");
                Console.WriteLine("7. Quan ly nhiet do");
                Console.WriteLine("8. Thong ke tan suat tu");
                Console.WriteLine("9. Xu ly so nguyen");
                Console.WriteLine("10. Ma tran xoan oc");
                Console.WriteLine("11. Ma tran dac biet");
                Console.WriteLine("12. Game Minesweeper");
                Console.WriteLine("13. Dao nguoc DSLK");
                Console.WriteLine("14. Gop hai DSLK");
                Console.WriteLine("15. Phat hien chu trinh");
                Console.WriteLine("16. Lich su duyet web");
                Console.WriteLine("17. Playlist nhac");
                Console.WriteLine("18. He thong dat hang");
                Console.WriteLine("0. Thoat");
                Console.Write("Chon bai: ");

                string chon = Console.ReadLine();

                switch (chon)
                {
                    case "1": Bai1.Run(); break;
                    case "2": Bai2.Run(); break;
                    case "3": Bai3.Run(); break;
                    case "4": Bai4.Run(); break;
                    case "5": Bai5.Run(); break;
                    case "7": Bai7.Run(); break;
                    case "8": Bai8.Run(); break;
                    case "9": Bai9.Run(); break;
                    case "10": Bai10.Run(); break;
                    case "11": Bai11.Run(); break;
                    case "12": Bai12.Run(); break;
                    case "13": Bai13.Run(); break;
                    case "14": Bai14.Run(); break;
                    case "15": Bai15.Run(); break;
                    case "16": Bai16.Run(); break;
                    case "17": Bai17.Run(); break;
                    case "18": Bai18.Run(); break;
                    case "0": return;
                    default:
                        Console.WriteLine("Lua chon khong hop le!");
                        break;
                }
            }
        }
    }
}
